const fs = require('fs-extra');
const AUTODELETE_FILE = './autodelete_channels.json';

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot) return;

    if (fs.existsSync(AUTODELETE_FILE)) {
      const config = fs.readJsonSync(AUTODELETE_FILE);
      const minutes = config[message.channel.id];
      if (minutes) {
        setTimeout(() => {
          message.delete().catch(() => {});
        }, minutes * 60 * 1000);
      }
    }
  }
};