const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('delete')
    .setDescription('🗑️ Löscht Nachrichten im aktuellen Channel')
    .addIntegerOption(option =>
      option.setName('amount').setDescription('Anzahl der zu löschenden Nachrichten').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    if (amount < 1 || amount > 100) {
      return interaction.reply({ content: '❌ Bitte gib eine Zahl zwischen 1 und 100 an.', ephemeral: true });
    }
    await interaction.channel.bulkDelete(amount, true);
    logger.logAction(interaction.guild, `${interaction.user.tag} hat ${amount} Nachrichten gelöscht.`);
    await interaction.reply({ content: `🗑️ ${amount} Nachrichten gelöscht!`, ephemeral: false });
  }
};