const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../utils/logger');
const fs = require('fs-extra');

const AUTODELETE_FILE = './autodelete_channels.json';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autodelete')
    .setDescription('⏳ Aktiviert/Deaktiviert Auto-Delete für einen Channel')
    .addChannelOption(option =>
      option.setName('channel').setDescription('Channel für Auto-Delete').setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('minutes').setDescription('Zeit in Minuten bis Nachrichten gelöscht werden (0 = deaktivieren)').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const minutes = interaction.options.getInteger('minutes');

    let config = {};
    if (fs.existsSync(AUTODELETE_FILE)) {
      config = fs.readJsonSync(AUTODELETE_FILE);
    }

    if (minutes > 0) {
      config[channel.id] = minutes;
      await interaction.reply(`⏳ Auto-Delete für <#${channel.id}> auf ${minutes} Minuten gesetzt.`);
    } else {
      delete config[channel.id];
      await interaction.reply(`⏳ Auto-Delete für <#${channel.id}> deaktiviert.`);
    }

    fs.writeJsonSync(AUTODELETE_FILE, config);

    logger.logAction(interaction.guild, `${interaction.user.tag} hat Auto-Delete für ${channel.name} auf ${minutes} Minuten gesetzt.`);
  }
};