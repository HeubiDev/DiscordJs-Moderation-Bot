const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ticketUtils = require('../utils/ticketUtils');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('🎟️ Erstellt ein neues Support-Ticket'),
  async execute(interaction) {
    await ticketUtils.createTicket(interaction);
  }
};