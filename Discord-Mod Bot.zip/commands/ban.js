const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('🚨 Bannt einen Benutzer vom Server')
    .addUserOption(option =>
      option.setName('user').setDescription('Benutzer, der gebannt wird').setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason').setDescription('Grund für den Ban').setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Kein Grund angegeben';
    const member = await interaction.guild.members.fetch(user.id);

    if (!member.bannable) {
      return interaction.reply({ content: '❌ Dieser Benutzer kann nicht gebannt werden!', ephemeral: true });
    }

    await member.ban({ reason });
    logger.logAction(interaction.guild, `${interaction.user.tag} hat ${user.tag} gebannt. Grund: ${reason}`);
    await interaction.reply({ content: `✅ ${user.tag} wurde gebannt! 🚨`, ephemeral: false });
  }
};