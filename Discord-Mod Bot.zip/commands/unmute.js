const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('🔊 Hebt das Stummschalten eines Benutzers auf')
    .addUserOption(option =>
      option.setName('user').setDescription('Benutzer, der entmutet wird').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(user.id);

    const muteRole = interaction.guild.roles.cache.find(role => role.name === 'Muted');
    if (!muteRole || !member.roles.cache.has(muteRole.id)) {
      return interaction.reply({ content: '❌ Benutzer ist nicht gemutet!', ephemeral: true });
    }

    await member.roles.remove(muteRole);
    logger.logAction(interaction.guild, `${interaction.user.tag} hat ${user.tag} entmutet.`);
    await interaction.reply({ content: `🔊 ${user.tag} wurde entmutet!`, ephemeral: false });
  }
};