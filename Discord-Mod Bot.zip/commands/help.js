const { SlashCommandBuilder } = require('discord.js');
const commandsList = [
  '`/ban` – Bannt einen Benutzer 🚨',
  '`/kick` – Kickt einen Benutzer 👢',
  '`/mute` – Stummt einen Benutzer 🔇',
  '`/unmute` – Entmutet einen Benutzer 🔊',
  '`/delete` – Löscht Nachrichten 🗑️',
  '`/autodelete` – Auto-Delete Nachrichten ⏳',
  '`/ticket` – Ticket Support 🎟️'
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('📋 Zeigt alle verfügbaren Moderationsbefehle'),
  async execute(interaction) {
    await interaction.reply({
      content: `📋 **Moderationsbefehle:**\n\n${commandsList.join('\n')}`,
      ephemeral: true
    });
  }
};