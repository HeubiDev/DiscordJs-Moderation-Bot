const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('👢 Kickt einen Benutzer vom Server')
    .addUserOption(option =>
      option.setName('user').setDescription('Benutzer, der gekickt wird').setRequired(true)
    )
    .addStringOption(option =>
      option.setName('reason').setDescription('Grund für den Kick').setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'Kein Grund angegeben';
    const member = await interaction.guild.members.fetch(user.id);

    if (!member.kickable) {
      return interaction.reply({ content: '❌ Dieser Benutzer kann nicht gekickt werden!', ephemeral: true });
    }

    await member.kick(reason);
    logger.logAction(interaction.guild, `${interaction.user.tag} hat ${user.tag} gekickt. Grund: ${reason}`);
    await interaction.reply({ content: `✅ ${user.tag} wurde gekickt! 👢`, ephemeral: false });
  }
};