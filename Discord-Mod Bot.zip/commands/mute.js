const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('🔇 Schaltet einen Benutzer stumm')
    .addUserOption(option =>
      option.setName('user').setDescription('Benutzer, der gemutet wird').setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(user.id);

    let muteRole = interaction.guild.roles.cache.find(role => role.name === 'Muted');
    if (!muteRole) {
      muteRole = await interaction.guild.roles.create({ name: 'Muted', permissions: [] });
      interaction.guild.channels.cache.forEach(c => c.permissionOverwrites.edit(muteRole, { SendMessages: false }));
    }

    await member.roles.add(muteRole);
    logger.logAction(interaction.guild, `${interaction.user.tag} hat ${user.tag} gemutet.`);
    await interaction.reply({ content: `🔇 ${user.tag} wurde stummgeschaltet!`, ephemeral: false });
  }
};